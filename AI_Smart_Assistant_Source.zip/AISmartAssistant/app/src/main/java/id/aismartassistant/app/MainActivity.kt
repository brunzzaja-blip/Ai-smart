package id.aismartassistant.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

private val Navy = Color(0xFF101A35)
private val Purple = Color(0xFF6558D3)
private val Ink = Color(0xFF17213A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF9B91FF), background = Navy, surface = Color(0xFF1B2745))) { AssistantApp() } }
    }
}

@Composable
fun AssistantApp() {
    var page by remember { mutableStateOf("home") }
    var prompt by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("80") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun ask(mode: String) {
        if (prompt.isBlank()) { result = "Masukkan soal atau materi terlebih dahulu."; return }
        if (apiKey.isBlank()) { result = "Masukkan Gemini API key pada kolom konfigurasi di bawah. Tanpa API key, AI belum bisa memberi jawaban."; return }
        loading = true
        result = "Sedang menganalisis..."
        scope.launch {
            result = try { Gemini.ask(apiKey, mode, prompt, target.toIntOrNull() ?: 80) }
            catch (e: Exception) { "Gagal menghubungi AI: ${e.message ?: "periksa koneksi dan API key"}" }
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, Color(0xFF202D54)))).verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(14.dp), color = Purple, modifier = Modifier.size(46.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = Color.White) }
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("AI SMART ASSISTANT", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = Color.White)
                Text("Asisten belajar dengan AI", color = Color(0xFFB9C4E2), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(26.dp))
        if (page == "home") {
            Text("Pilih fitur", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Gunakan untuk latihan dan memahami materi.", color = Color(0xFFB9C4E2))
            Spacer(Modifier.height(18.dp))
            FeatureCard("Jawab Soal Otomatis", "Analisis soal latihan dan berikan jawaban beserta alasan.", Icons.Default.AutoAwesome) { page = "answer"; prompt = ""; result = "" }
            FeatureCard("Jawaban Diisi AI", "Susun draf jawaban agar bisa kamu tinjau dan salin sendiri.", Icons.Default.Edit) { page = "draft"; prompt = ""; result = "" }
            FeatureCard("Auto Nilai di Atas KKM", "Mode latihan dengan target KKM. AI membantu mengevaluasi jawaban dan menunjukkan bagian yang perlu diperbaiki.", Icons.Default.TrackChanges) { page = "kkm"; prompt = ""; result = "" }
            Spacer(Modifier.height(16.dp))
            Text("Konfigurasi AI", color = Color.White, fontWeight = FontWeight.Bold)
            OutlinedTextField(apiKey, { apiKey = it }, label = { Text("Gemini API key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("API key dipakai di perangkat ini. Untuk aplikasi publik, gunakan backend agar key tidak tertanam di APK.", color = Color(0xFFB9C4E2), fontSize = 11.sp)
        } else {
            Text(pageTitle(page), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(pageDescription(page), color = Color(0xFFB9C4E2))
            Spacer(Modifier.height(16.dp))
            if (page == "kkm") {
                OutlinedTextField(target, { target = it.filter(Char::isDigit).take(3) }, label = { Text("Target KKM (0–100)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
            }
            OutlinedTextField(prompt, { prompt = it }, label = { Text(if (page == "draft") "Tulis instruksi / pertanyaan" else "Masukkan soal latihan") }, modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp), minLines = 4)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { ask(page) }, enabled = !loading, modifier = Modifier.fillMaxWidth()) { Text(if (loading) "Memproses..." else "Minta bantuan AI") }
            if (result.isNotBlank()) {
                Spacer(Modifier.height(16.dp))
                Surface(color = Color(0xFF26365D), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(result, color = Color.White, modifier = Modifier.padding(16.dp))
                }
            }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = { page = "home"; result = "" }, modifier = Modifier.fillMaxWidth()) { Text("Kembali") }
        }
        Spacer(Modifier.height(22.dp))
        Text("Catatan: fitur ini untuk belajar dan latihan. Tidak mengisi ujian aktif, mengakses Exambro, atau memanipulasi nilai.", color = Color(0xFF9EABC9), fontSize = 11.sp)
    }
}

@Composable
fun FeatureCard(title: String, desc: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F8FF))) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0xFFE9E8FF), shape = RoundedCornerShape(14.dp), modifier = Modifier.size(48.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Purple) }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text(desc, color = Color(0xFF59647D), fontSize = 12.sp)
            }
        }
    }
}

fun pageTitle(p: String) = when(p) { "answer" -> "Jawab Soal Otomatis"; "draft" -> "Jawaban Diisi AI"; else -> "Target KKM" }
fun pageDescription(p: String) = when(p) {
    "answer" -> "Masukkan soal latihan. AI akan menjawab dan menjelaskan langkahnya."
    "draft" -> "AI menyusun draf jawaban untuk kamu periksa dan salin sendiri."
    else -> "Masukkan soal dan jawabanmu. AI memberi evaluasi serta saran belajar menuju target KKM, bukan mengubah nilai."
}

object Gemini {
    suspend fun ask(key: String, mode: String, prompt: String, target: Int): String = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val instruction = when(mode) {
            "answer" -> "Bantu jawab soal latihan berikut. Berikan jawaban dan penjelasan langkah demi langkah. Jika informasi kurang, katakan."
            "draft" -> "Buat draf jawaban belajar yang jelas dan akurat untuk ditinjau pengguna. Jangan mengirim atau mengisi formulir."
            else -> "Evaluasi jawaban latihan pengguna berikut. Target belajar KKM adalah $target/100. Jelaskan konsep yang benar, koreksi kekeliruan, dan beri latihan perbaikan. Jangan menjanjikan atau memanipulasi nilai."
        }
        val body = JSONObject().put("contents", org.json.JSONArray().put(JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", "$instruction\n\n$prompt")))))
        val conn = (URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key").openConnection() as HttpURLConnection)
        conn.requestMethod = "POST"; conn.connectTimeout = 20000; conn.readTimeout = 30000
        conn.doOutput = true; conn.setRequestProperty("Content-Type", "application/json")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        val json = JSONObject(response)
        if (!json.has("candidates")) throw Exception(json.optJSONObject("error")?.optString("message") ?: "respons API tidak valid")
        json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }
}
