# AI Smart Assistant (Android)

Starter project Kotlin + Jetpack Compose dengan tepat tiga fitur:
1. Jawab Soal Otomatis (untuk soal latihan)
2. Jawaban Diisi AI (membuat draf; pengguna meninjau/menyalin sendiri)
3. Auto Nilai di Atas KKM (diimplementasikan sebagai evaluasi latihan berbasis target KKM, bukan manipulasi nilai)

## Build APK
- Buka folder proyek ini di Android Studio (versi yang mendukung AGP 8.7.3).
- Tunggu Gradle Sync.
- Jalankan pada perangkat Android atau pilih Build > Build APK(s).
- APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Mengaktifkan AI
- Buat Gemini API key melalui Google AI Studio.
- Jalankan aplikasi, masukkan key pada kolom Gemini API key di halaman awal.
- Koneksi internet diperlukan.
- Jangan membagikan API key. Untuk distribusi ke banyak pengguna, pindahkan panggilan AI ke backend milik sendiri; key yang dimasukkan di aplikasi bukan penyimpanan rahasia tingkat produksi.

## Batasan versi awal
- Input saat ini berupa teks. Upload foto/OCR, riwayat, dan floating overlay belum disertakan.
- Fitur hanya untuk belajar/latihan; tidak mengakses atau mengisi ujian aktif, Exambro, atau mengubah hasil penilaian.
